package com.example.sheha.myfirstapp;

/**
 * Created by sheha on 12/9/2017.
 */

public class LogOtherError {
    public String errorId;
    public String errorDesc;
    public String errorTime;


    public LogOtherError(String errorId, String errorDesc, String errorTime){
        this.errorId=errorId;
        this.errorDesc=errorDesc;
        this.errorTime=errorTime;

    }
}
